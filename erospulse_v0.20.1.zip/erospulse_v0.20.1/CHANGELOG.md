# Changelog — ErosPulse

Toutes les versions notables du projet sont documentées ici. Le
projet s'appelait "Lovense Text-to-Vibe" jusqu'à la v0.10.0.

## v0.20.1

**Correctif : page de séquence inaccessible**
- Une fois le toy connecté, le bouton « Commencer » affichait l'erreur
  « La page « text » n'a pas pu se charger. name 'Path' is not defined ».
- Cause : le correctif de persistance de la v0.19.1 avait retiré
  `from pathlib import Path` de `core/settings.py`, alors que
  `get_import_folder()` utilise encore `Path(...)` dès qu'un dossier de
  modèles personnalisé est enregistré (via « Dossier… » ou le profil).
  Sans dossier personnalisé, le code n'était jamais exécuté, donc mes
  vérifications d'alors ne l'avaient pas détecté.
- Import rétabli. Un contrôle statique des noms non définis a été
  exécuté sur tout le projet (hors dépendances vendorisées) : aucun
  autre cas, et ce contrôle détecte bien l'erreur d'origine.
- Vérifié de bout en bout : page chargée avec un dossier personnalisé
  configuré, puis scénario complet du mode Mini (lecture lancée depuis
  le mode Mini, pause, retour en vue normale sans interruption,
  reprise, fin de séquence, Stop / Reset, temps de vibration ajouté au
  profil).

## v0.20.0

**Mode Mini**
- Nouvelle vue alternative de la page de séquence, basée sur la
  maquette fournie : en-tête « ← Modifier la séquence » + statut de
  connexion, graphique agrandi avec l'annotation « ▶ Playhead »,
  « temps écoulé » (gauche) et « durée totale » (droite) au format
  `mm:ss`, et deux gros boutons **Play / Resume** (qui devient
  « Pause » pendant la lecture) et **Stop / Reset**.
- Accès par un bouton « ⤢ Mode Mini » dans la barre d'import, à la
  place de l'ancien chemin du dossier (désormais consultable dans la
  fenêtre de profil).
- C'est la **même page** affichée différemment (pas une page séparée) :
  mêmes threads, mêmes minuteurs, même état de lecture. Passer du mode
  Normal au mode Mini et inversement n'interrompt donc jamais la
  lecture en cours ; les deux vues (graphiques, boutons, statut de
  connexion, messages) sont tenues synchronisées en permanence, même
  quand l'une est cachée.
- Un petit message de progression est ajouté en mode Mini (commande en
  cours, boucle, erreurs de saisie) : sans lui, un clic sur Play avec un
  éditeur vide n'aurait donné aucun retour visible. Légère entorse à la
  maquette, assumée.
- La légende des moteurs reste à l'intérieur du cadre du graphique
  (comme en vue normale) plutôt que dessous, pour réutiliser le même
  composant sans le dupliquer.
- `SequenceChart` gagne un paramètre `show_playhead_label` (activé
  uniquement pour le graphique du mode Mini, avec une rangée dédiée
  sous la légende pour éviter tout chevauchement).
- Le **temps de vibration effectif** est maintenant réellement ajouté
  au profil utilisateur à chaque lecture terminée (durée totale) ou
  arrêtée (temps réellement joué) — la statistique affichée dans la
  fenêtre de profil, jusque-là toujours à zéro, se met enfin à jour.

## v0.19.1

**Correctif : persistance du profil et des réglages**
- Le profil utilisateur et le dossier des modèles configuré ne
  survivaient pas à la fermeture de l'application une fois celle-ci
  empaquetée en exécutable (`.exe` via PyInstaller / `build_exe.bat` /
  `build_exe.sh`). Cause : leur chemin de sauvegarde était calculé à
  partir de `__file__`, qui pointe vers le dossier temporaire
  d'extraction de PyInstaller (`sys._MEIPASS`) une fois l'app
  empaquetée — un dossier recréé, différent, à chaque lancement, et
  jeté à la fermeture. Tout ce qui y était écrit disparaissait donc.
- Nouveau module `core/app_paths.py` : détecte si l'app tourne comme
  exécutable figé (`sys.frozen`) et, dans ce cas, stocke les fichiers
  persistés à côté de l'exécutable lui-même plutôt que dans ce dossier
  temporaire. En exécution depuis les sources Python, le comportement
  est inchangé (dossier du projet).
- `core/user_profile.py` et `core/settings.py` utilisent désormais ce
  module commun, pour stocker `profile.json` et `settings.json` au
  même endroit stable, avec la même logique.
- Vérifié avec une simulation d'exécutable figé (`sys.frozen` +
  `sys.executable` forcés) : les données écrites lors d'un "lancement"
  sont bien relues intactes lors d'un second "lancement" simulé dans un
  nouveau process.

## v0.19.0

**Profil utilisateur**
- Nouveau module `core/user_profile.py` : profil persisté (prénom,
  nombre d'ouvertures de l'application, temps de vibration effectif
  cumulé, dernière IP de connexion utilisée), stocké dans son propre
  fichier `profile.json` à la racine du projet. Se met à jour et se
  sauvegarde automatiquement au fil de l'usage — aucune action de
  l'utilisateur n'est nécessaire pour qu'il persiste d'une session à
  l'autre. Nom par défaut : `A`.
- Nouvelle fenêtre `ui/profile_window.py` (Toplevel), accessible via un
  bouton "buste de personne" en haut à gauche de la page d'accueil —
  qui remplace le libellé texte "ErosPulse" à cet emplacement. Permet :
  - de modifier et enregistrer son prénom ;
  - de consulter le nombre d'ouvertures de l'app et le temps de
    vibration effectif cumulé (format h:mm:ss) ;
  - de choisir le dossier des modèles (réutilise
    `core/settings.py`, déjà utilisé par la page de séquence) ;
  - d'**exporter** l'ensemble de ces informations vers un fichier texte,
    et de les **importer** depuis un tel fichier pour les restaurer.
- La page de connexion enregistre désormais automatiquement l'IP dans
  le profil dès qu'une connexion réussit, et pré-remplit le champ IP
  avec la dernière IP connue au chargement de la page.
- `ui/app_window.py` incrémente le compteur d'ouvertures une fois par
  lancement de l'application.
- Le temps de vibration effectif (ajouté au profil à chaque lecture
  terminée ou arrêtée) sera branché à la page de séquence dans une
  prochaine mise à jour.

## v0.18.1

**Durées décimales**
- Le champ `D` du format `[Y;D;[A;B]]` accepte désormais les nombres
  décimaux (ex: `[1;1.5;[10;0]]` pour une vibration de 1,5 seconde),
  en plus des entiers. `Y`, `N` (dans `LOOP(N){...}`), `A` et `B`
  restent des entiers (un moteur, un nombre de répétitions ou une
  intensité n'ont pas de sens en décimal).
- `VibrationCommand.duration` est donc typé `float`, mais une durée
  ronde (ex: `2`) reste stockée et affichée comme un entier propre
  (`[1;2;[5;0]]`, pas `[1;2.0;[5;0]]`).
- Confirmé de bout en bout : le réseau transmettait déjà des durées
  décimales (`timeSec`) en interne pour la reprise après pause ; c'était
  uniquement le format texte qui ne les acceptait pas en entrée.
- `core/ai_prompt.py` mis à jour pour indiquer que les décimales sont
  permises.

## v0.18.0

**Correctifs de synchronisation**

Le graphique d'intensité et le décompte de temps restant étaient
calculés par un minuteur indépendant (basé uniquement sur l'horloge
murale écoulée depuis le lancement de la lecture), déconnecté du
déroulement réel de la séquence côté réseau. Résultat : une dérive
progressive, en particulier à cause du temps réseau de chaque envoi de
commande (notamment perceptible sur les commandes à deux moteurs, qui
envoient deux requêtes). Le message de progression, lui, était déjà
correct car directement piloté par les événements réels du thread de
lecture (`on_command_start`).

- Le graphique et le décompte sont désormais **resynchronisés sur ces
  mêmes événements réels** : à chaque vrai début de commande, le repère
  du graphique et le calcul du temps restant sont recalés sur le temps
  cumulé nominal de la séquence à cet instant précis — éliminant toute
  dérive, y compris due à la latence réseau. Entre deux débuts de
  commande, l'affichage continue d'avancer de façon fluide par
  interpolation, mais toujours ancré sur le dernier point réel connu.
- La pause/reprise a été adaptée en conséquence : à la reprise, le
  point d'ancrage est réinitialisé pour que le temps passé en pause ne
  soit jamais compté comme du temps de lecture.
- Vérifié avec une latence réseau artificielle (0.3-0.4s par commande) :
  le repère du graphique retombe exactement sur les valeurs nominales
  attendues (0s, 1s, 2s...) à chaque vrai changement de commande, quelle
  que soit la latence accumulée pour y arriver.

**Affichage de l'occurrence de boucle**
- `core/vibration_command.py` : nouvelle fonction
  `parse_sequence_detailed()` qui renvoie, en plus de chaque commande,
  sa position dans les éventuelles boucles `LOOP(N){...}` qui la
  contiennent (boucles imbriquées gérées, niveau par niveau).
  `parse_sequence()` reste inchangée (rétrocompatible).
- Le message de progression affiche maintenant cette information, ex:
  `Commande 3/6 (boucle 2/3) — [1;2;[10;0]]`, ou
  `(boucle 1/2 > 3/3)` pour des boucles imbriquées.

## v0.17.0

**Pastille de statut sur la page de séquence**
- Ajout d'une pastille colorée (verte = connecté, orange = non
  connecté) à côté du label de statut de connexion en haut à droite de
  la page de séquence, reprenant exactement le même style que sur la
  page d'accueil (`ui/pages/home_page.py`).
- La couleur se met à jour automatiquement à chaque retour sur la page
  (`on_show()`), en cohérence avec le texte déjà affiché.

## v0.16.0

**Import de modèles de séquence**
- Nouveau module `core/settings.py` : réglages persistés sur disque
  (fichier `settings.json` à la racine du projet), pour l'instant
  limités au dossier configuré pour les modèles importables — mais
  conçu pour accueillir d'autres préférences à l'avenir.
- Nouveau module `core/template_library.py` : découverte des fichiers
  `.txt` dans un dossier donné, et lecture de leur contenu. Aucune
  validation du contenu ici : un modèle chargé est traité exactement
  comme du texte tapé à la main (même parsing, mêmes erreurs possibles).
- Page de séquence : nouveau menu déroulant listant les fichiers `.txt`
  du dossier configuré (par défaut `Import/` à la racine du projet,
  créé automatiquement s'il n'existe pas encore). Sélectionner un
  modèle remplace le contenu de l'éditeur et met à jour
  immédiatement la durée totale et le graphique.
- Bouton **"Dossier…"** pour choisir un autre dossier via le sélecteur
  natif du système ; le choix est mémorisé pour les prochains
  lancements. Bouton **⟳** pour rafraîchir manuellement la liste ; elle
  se rafraîchit aussi automatiquement à chaque retour sur la page.
- Bouton **"Masquer le texte" / "Afficher le texte"** : replie ou
  déplie la zone d'édition (le contenu est conservé même masqué,
  seul l'affichage change).
- Un exemple (`Import/Exemple - vague.txt`, utilisant `LOOP`) est
  fourni avec le projet pour que la fonctionnalité soit visible dès le
  premier lancement.

## v0.15.0

**Boucles LOOP(N){...}**
- Nouvelle syntaxe dans `core/vibration_command.py` : un bloc
  `LOOP(N){ Z }` répète N fois le contenu `Z` (une ou plusieurs
  commandes `[Y;D;[A;B]]`), sans avoir à le retaper. Exemple :
  `LOOP(3){[1;2;[10;0]] [2;2;[0;15]]}` équivaut à écrire la paire de
  commandes 3 fois de suite.
- Les boucles peuvent être imbriquées (`LOOP(2){... LOOP(3){...}}`)
  et mélangées librement avec des commandes normales avant/après.
- `parse_sequence()` a été réécrit en un vrai parseur récursif (les
  accolades imbriquées ne sont pas gérables de façon fiable avec une
  simple regex), mais continue de renvoyer une **liste plate** de
  `VibrationCommand`, boucles entièrement développées : la lecture, le
  graphique et le calcul de durée totale fonctionnent donc avec `LOOP`
  sans la moindre modification.
- `LOOP(0){...}` est accepté et ignore simplement son contenu ; un
  bloc `LOOP(...)` non refermé lève une erreur claire
  (`SequenceSyntaxError`, une sous-classe de `ValueError`, déjà gérée
  par l'interface).
- `core/ai_prompt.py` mis à jour pour que l'IA sache utiliser `LOOP`
  quand c'est pertinent (motif qui se répète à l'identique), sans
  l'imposer pour des séquences qui évoluent (montée d'intensité, etc.).

## v0.14.0

**Génération d'un exécutable autonome**
- Ajout de `ErosPulse.spec`, une configuration PyInstaller prête à
  l'emploi (mode fenêtré sans console, exécutable en un seul fichier,
  toutes les dépendances embarquées via `vendor/`).
- Ajout de `build_exe.bat` (Windows) et `build_exe.sh` (macOS/Linux) :
  scripts qui installent PyInstaller puis lancent la génération de
  l'exécutable en une seule commande / double-clic. Le résultat est
  déposé dans `dist/ErosPulse.exe` (Windows) ou `dist/ErosPulse`
  (macOS/Linux).
- **Important : PyInstaller ne fait pas de compilation croisée.** Un
  `.exe` Windows doit être généré en exécutant le script *sur
  Windows* (idem : un `.app` macOS se génère sur macOS, un binaire
  Linux se génère sur Linux). Ces scripts doivent donc être exécutés
  par l'utilisateur final sur sa propre machine — ils ne peuvent pas
  être pré-générés depuis un environnement de développement Linux
  pour produire un `.exe` Windows valide.

## v0.13.0

**Graphique intensité(t)**
- Nouveau widget `ui/widgets/sequence_chart.py` (`SequenceChart`,
  sous-classe de `tk.Canvas`) : dessine l'intensité de chaque moteur
  au cours du temps sous forme de deux courbes en "escalier" (une par
  moteur), échelle 0-20, avec grille et légende. Aucune dépendance
  externe (pas de matplotlib) : tout est dessiné à la main sur le
  Canvas, cohérent avec le principe "zéro dépendance" du projet.
- Le graphique se met à jour en direct pendant la saisie du texte, et
  affiche un repère vertical ("playhead") indiquant la position de
  lecture actuelle pendant l'exécution — figé pendant une pause,
  masqué à la fin de la lecture.
- Une commande à durée infinie (D=0) est représentée par un segment
  symbolique avec une annotation ; le graphique s'arrête à ce point
  comme le fait réellement `play_sequence()`.
- Placé en bas de la page de texte (hauteur fixe, toujours visible),
  entre la zone de texte et la barre de statut.

**Persistance du message "commande en cours"**
- Le message `"Commande X/Y — [Y;D;[A;B]]"` est maintenant conservé
  (`self._current_command_text`) et restauré après une pause, un
  aller-retour vers l'accueil, ou une reprise — au lieu d'être
  remplacé par un texte générique "Reprise…" qui faisait perdre cette
  information.

## v0.12.0

**Correctifs**

1. Retrait du texte "Connexion à l'Edge 2" à côté du bouton "← Accueil"
   sur la page de connexion.

2. Le bouton "← Accueil" de la page de séquence **met en pause** une
   lecture en cours (coupure physique immédiate du toy) au lieu de
   l'arrêter définitivement. Comme `AppWindow` garde toutes les pages
   construites en mémoire (elles ne sont jamais détruites en changeant
   de page), le thread de lecture reste en pause en arrière-plan : en
   revenant sur la page, le bouton affiche "Reprendre" et permet de
   relancer la séquence exactement là où elle s'était arrêtée (même
   mécanisme de reprise avec temps restant qu'en v0.10.0).

3. et 4. Mise en page de la page de séquence entièrement revue :
   remplacement des positionnements relatifs (`place(relx=..., rely=...)`)
   par un empilement `pack()` ancré aux bords (header en haut, décompte
   + compteur de caractères + boutons + message de progression ancrés
   en bas). Ces éléments restent donc toujours visibles quelle que soit
   la taille de la fenêtre ; seule la zone de texte s'agrandit ou se
   réduit. Le texte d'aide au-dessus de la zone de saisie recalcule
   désormais dynamiquement son retour à la ligne (`wraplength`) à
   chaque redimensionnement (`<Configure>`), au lieu d'une largeur
   fixe qui débordait sur les petites fenêtres.

## v0.11.0

**Page de séquence**
- Retrait du libellé "Ton texte" à côté du bouton "← Accueil".
- Ajout d'un décompte au format `min:sec` :
  - pendant la saisie, affiche la **durée totale** de la séquence
    tapée (`Durée totale : 0:12`), recalculée à chaque modification
    du texte ;
  - pendant la lecture, devient un **compte à rebours du temps
    restant** (`Temps restant : 0:08`), rafraîchi chaque seconde ;
  - se **fige pendant une pause** (le temps ne défile pas tant que la
    lecture n'a pas repris) ;
  - affiche "indéterminée (boucle infinie)" si la séquence contient
    une commande à durée 0 (impossible à borner).

## v0.10.0

**Rebranding**
- L'application s'appelle désormais **ErosPulse** (au lieu de
  "Lovense Text-to-Vibe"). Nom mis à jour dans `core/version.py`
  (source unique de vérité, propagée au titre de la fenêtre et à la
  page d'accueil), sur la page d'accueil (bandeau + titre principal),
  et dans les fichiers projet Visual Studio (`ErosPulse.pyproj`,
  `ErosPulse.sln`, remplaçant `LovenseTextToVibe.*`).
- Texte de la page d'accueil mis à jour pour refléter le fonctionnement
  actuel (séquence `[Y;D;[A;B]]` plutôt que texte libre pour l'instant).

**Pause / Reprendre**
- Le bouton "Arrêter" de la page de texte devient **Pause** /
  **Reprendre**. En pause, le toy est immédiatement coupé
  (`client.stop()`) ; à la reprise, la commande en cours est relancée
  pour le temps de vibration qu'il restait à jouer (et non depuis le
  début), avant de continuer normalement la séquence.
- `core/vibration_command.play_sequence()` accepte un nouveau paramètre
  `pause_event`, avec suivi du temps restant par polling (toutes les
  0.2s) pour rester réactif à un clic sur Pause/Reprendre.
- Quitter la page de texte pendant une lecture (bouton "← Accueil")
  arrête désormais proprement la séquence en cours, plutôt que de
  laisser le thread continuer à piloter le toy en arrière-plan.

## v0.9.0

**Exécution réelle de la séquence saisie**
- Le bouton **Générer le modèle de vibration** de la page de texte est
  maintenant branché : il parse le texte saisi avec
  `core.vibration_command.parse_sequence()`, puis joue la séquence
  obtenue sur le toy connecté via `play_sequence()`, dans un thread
  séparé pour ne pas geler l'interface.
- Affichage de la progression en direct : "Commande 2/5 —
  [2;1;[0;12]]", etc.
- Nouveau bouton **Arrêter**, qui interrompt la séquence en cours
  (via le `stop_event` de `play_sequence()`).
- Gestion propre des cas limites :
  - texte vide → message d'invite,
  - texte sans commande `[Y;D;[A;B]]` valide → message d'erreur clair,
  - toy non connecté → redirection automatique vers la page de
    connexion (comme le fait déjà le bouton "Commencer" de l'accueil).
- `core/vibration_command.play_sequence()` accepte désormais un
  callback `on_command_start(index, total, command)` pour permettre
  cet affichage de progression.

## v0.8.0

**Prompt IA pour la génération de séquences**
- Nouveau fichier `core/ai_prompt.py`, contenant `TEXT_TO_VIBRATION_PROMPT` :
  un prompt système complet expliquant à une IA (LLM) le format
  `[Y;D;[A;B]]` défini en v0.7.0, avec :
  - la spécification stricte du format et des bornes de chaque champ,
  - les règles de conversion texte → vibration (ponctuation, emphase,
    rythme, montée en intensité, transitions),
  - un exemple d'entrée/sortie complet.
- L'exemple de sortie fourni dans le prompt a été vérifié comme étant
  réellement parsable par `core/vibration_command.parse_sequence()`,
  pour garantir la cohérence entre ce que l'IA est invitée à produire
  et ce que l'application sait effectivement interpréter.
- Ce prompt sera utilisé par un futur module d'appel à une IA (ex: API
  Anthropic) pour générer automatiquement la séquence de vibration à
  partir du texte saisi sur la page de saisie.

## v0.7.0

**Format de commande de vibration**
- Nouveau module `core/vibration_command.py` implémentant le format
  `[Y;D;[A;B]]` :
  - `Y` : moteur ciblé (1 = interne, 2 = périnée, 3 = les deux)
  - `D` : durée en secondes (0 = boucle indéfinie, comme le reste de
    l'API Lovense)
  - `[A;B]` : intensités des moteurs 1 et 2 (0-20, bornées automatiquement)
- `VibrationCommand.from_string()` / `.to_string()` pour parser et
  sérialiser une commande unique ; `parse_sequence()` pour extraire
  toutes les commandes présentes dans un texte plus large.
- `send_command()` envoie une commande au toy. Pour `Y=3` (les deux
  moteurs), deux requêtes sont envoyées automatiquement avec le bon
  réglage `stopPrevious` pour que les deux moteurs vibrent en même
  temps avec des intensités différentes sans se couper l'un l'autre.
- `play_sequence()` enchaîne plusieurs commandes en respectant la
  durée de chacune, avec un `stop_event` optionnel pour interrompre la
  lecture en cours de route.
- `core/lovense_client.py` : ajout du paramètre `stop_previous` à
  `vibrate()` et `vibrate_motor()` (correspond à `stopPrevious` dans
  l'API Lovense).

## v0.6.0

**Navigation conditionnelle + page de texte**
- Nouvelle page `ui/pages/text_page.py` : zone de saisie de texte
  (avec compteur de caractères, limite de 2000 caractères), point
  d'entrée pour la future génération de modèle de vibration.
- Le bouton **Commencer** de la page d'accueil :
  - redirige vers la page de connexion si aucun toy n'est connecté ;
  - redirige vers la nouvelle page de texte si un toy est connecté.
- La page de texte affiche le statut de connexion en temps réel et
  prévient si la connexion est perdue entre-temps.
- Le bouton "Générer le modèle de vibration" est en place mais pas
  encore branché : l'algorithme texte → vibration
  (`core/text_to_pattern.py`) arrive à l'étape suivante.

## v0.5.0

**Contrôle par moteur (Edge 2 = 2 moteurs)**
- Nouvelle méthode `LovenseClient.vibrate_motor(motor, strength, ...)`
  dans `core/lovense_client.py`, qui envoie les actions `Vibrate1:X` /
  `Vibrate2:X` du protocole Lovense pour piloter un moteur précis,
  plutôt que `Vibrate:X` qui agit sur tous les moteurs à la fois.
- La page de connexion propose désormais **deux boutons de test** :
  « Tester Moteur 1 (interne) » et « Tester Moteur 2 (périnée) ».
  Chacun se connecte automatiquement si besoin (comme en v0.4.1), puis
  envoie une courte vibration sur le moteur choisi uniquement.
- Le bouton "Se connecter" reste disponible séparément pour une
  simple vérification de connexion sans déclencher de vibration.

## v0.4.1

**Correctif de comportement**
- Le bouton **Tester** de la page de connexion se connecte désormais
  automatiquement (s'il n'y a pas déjà de connexion active) puis
  enchaîne directement sur l'envoi d'une courte vibration. Avant, il
  fallait obligatoirement cliquer sur "Se connecter" au préalable — le
  bouton "Tester" ne faisait rien tant que ce n'était pas fait.
- Si une connexion est déjà active, "Tester" ne refait pas d'appel
  `GetToys` inutile : il envoie directement la vibration.
- Le bouton "Se connecter" reste disponible séparément pour ceux qui
  veulent juste vérifier la connexion sans déclencher de vibration.

## v0.4.0

**Dépendances embarquées**
- Ajout d'un dossier `vendor/` contenant directement le code source de
  `requests` et de ses dépendances (`urllib3`, `certifi`, `idna`,
  `charset_normalizer`). Plus besoin de `pip install -r requirements.txt` :
  `python main.py` (ou double-clic) suffit désormais, même sur une
  machine sans aucun paquet Python tiers installé.
- `main.py` ajoute automatiquement `vendor/` en tête de `sys.path` avant
  tout import, de façon relative à l'emplacement du projet (fonctionne
  quel que soit le dossier depuis lequel on lance le script).
- Les binaires compilés spécifiques à Linux (`.so` de
  `charset_normalizer`) ont été retirés du vendoring pour garantir la
  portabilité (notamment vers Windows/Visual Studio) : la bibliothèque
  utilise automatiquement son repli 100% Python.
- `requirements.txt` est conservé à titre indicatif/documentaire, mais
  n'est plus nécessaire pour lancer l'application.

## v0.3.0

**Correctif critique**
- La page d'accueil ne s'affichait plus si une dépendance (`requests`)
  n'était pas installée : toutes les pages étaient construites (et donc
  importées) au démarrage, y compris la page de connexion qui dépend de
  `requests`/`urllib3`. Une dépendance manquante faisait planter
  l'application avant même l'affichage de la fenêtre.
- **Fix** : chargement paresseux des pages. Seule la page d'accueil
  (aucune dépendance externe) est construite au démarrage. Les autres
  pages sont importées/construites uniquement quand on y accède, avec un
  message d'erreur clair si une dépendance manque.

**Autres changements**
- Ajout d'un système de version centralisé (`core/version.py`), affiché
  dans le titre de la fenêtre et en pied de page d'accueil.
- Ajout de `requirements.txt`.
- Ajout de ce changelog.

## v0.2.0

- Ajout de la connexion au toy via le "Game Mode" de l'app Lovense
  Remote (LAN, IP + port, sans compte développeur).
- Nouvelle page `connection_page.py` (formulaire IP/port/HTTPS, test de
  vibration, statut de connexion synchronisé avec la page d'accueil).
- Réorganisation du code en modules à responsabilité unique :
  - `core/constants.py` — limites partagées
  - `core/lovense_client.py` — communication réseau avec le toy
  - `core/pattern_generator.py` — génération des modèles de vibration
  - `core/app_state.py` — état de connexion partagé entre les pages

## v0.1.0

- Première version : application de bureau (Tkinter) avec une page
  d'accueil présentant le projet.
