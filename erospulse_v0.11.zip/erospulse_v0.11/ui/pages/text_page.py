"""
text_page.py
============
Page de saisie de texte : l'utilisateur y écrit ou colle une séquence
de commandes de vibration au format [Y;D;[A;B]] (voir
core/vibration_command.py). Le bouton "Générer le modèle de vibration"
parse ce texte et joue la séquence obtenue sur le toy connecté.

Cette page suppose qu'un toy est déjà connecté (HomePage ne redirige
ici que si controller.state.connected est vrai). Si on clique sur
Générer sans connexion active, on redirige vers la page de connexion
plutôt que d'échouer silencieusement.

Pour l'instant, le texte saisi doit DÉJÀ être au format [Y;D;[A;B]]
(éventuellement généré par une IA suivant le prompt de
core/ai_prompt.py, collé ici manuellement). Le futur appel automatique
à une IA à partir d'un texte libre est une étape ultérieure.

Pendant la lecture, un bouton "Pause" (et non "Arrêter") permet de
suspendre la séquence : le toy est immédiatement coupé, et "Reprendre"
relance la commande en cours pour le temps de vibration qu'il restait
à jouer (voir play_sequence() / pause_event dans core/vibration_command.py).

Un décompte au format min:sec affiche la durée totale de la séquence
saisie, et devient un vrai compte à rebours du temps restant pendant la
lecture (figé pendant une pause).
"""

from __future__ import annotations

import threading
import tkinter as tk
from tkinter import ttk

from core.vibration_command import VibrationCommand, parse_sequence, play_sequence
from ui import theme

MAX_CHARS = 4000

# Intervalle (ms) de rafraîchissement du décompte pendant la lecture.
_COUNTDOWN_TICK_MS = 1000


def _format_mmss(total_seconds: float) -> str:
    """Formate une durée en secondes au format min:sec (ex: 125 -> '2:05')."""
    total_seconds = max(0, int(round(total_seconds)))
    minutes, seconds = divmod(total_seconds, 60)
    return f"{minutes}:{seconds:02d}"


class TextPage(tk.Frame):
    def __init__(self, parent: tk.Widget, controller) -> None:
        super().__init__(parent, bg=theme.BG_DARK)
        self.controller = controller

        self._playing = False
        self._stop_event: threading.Event | None = None
        self._pause_event: threading.Event | None = None
        self._remaining_seconds: float = 0.0

        self._build_header()
        self._build_editor()
        self._build_footer_actions()

    # ------------------------------------------------------------------
    def _build_header(self) -> None:
        header = tk.Frame(self, bg=theme.BG_DARK)
        header.pack(fill="x", padx=28, pady=(20, 0))

        back_btn = ttk.Button(
            header,
            text="← Accueil",
            style="Secondary.TButton",
            command=self._on_back,
        )
        back_btn.pack(side="left")

        self._connection_label = tk.Label(
            header,
            text="",
            bg=theme.BG_DARK,
            fg=theme.TEXT_SECONDARY,
            font=theme.FONT_SMALL,
        )
        self._connection_label.pack(side="right")

    # ------------------------------------------------------------------
    def _build_editor(self) -> None:
        wrapper = tk.Frame(self, bg=theme.BG_DARK)
        wrapper.place(relx=0.5, rely=0.44, anchor="center", relwidth=0.7, relheight=0.52)

        hint = tk.Label(
            wrapper,
            text="Colle ici une séquence de commandes au format [Y;D;[A;B]] "
                 "(Y = moteur, D = durée en secondes, [A;B] = intensités moteur 1 / moteur 2).",
            bg=theme.BG_DARK,
            fg=theme.TEXT_SECONDARY,
            font=theme.FONT_SMALL,
            wraplength=700,
            justify="left",
            anchor="w",
        )
        hint.pack(fill="x", pady=(0, 10))

        text_container = tk.Frame(wrapper, bg=theme.BG_CARD)
        text_container.pack(fill="both", expand=True)

        self._text_widget = tk.Text(
            text_container,
            bg=theme.BG_CARD,
            fg=theme.TEXT_PRIMARY,
            insertbackground=theme.TEXT_PRIMARY,
            font=theme.FONT_BODY,
            relief="flat",
            wrap="word",
            padx=14,
            pady=12,
            undo=True,
        )
        self._text_widget.pack(fill="both", expand=True, side="left")
        self._text_widget.bind("<<Modified>>", self._on_text_modified)

        scrollbar = ttk.Scrollbar(text_container, command=self._text_widget.yview)
        scrollbar.pack(fill="y", side="right")
        self._text_widget.config(yscrollcommand=scrollbar.set)

        footer_row = tk.Frame(wrapper, bg=theme.BG_DARK)
        footer_row.pack(fill="x", pady=(6, 0))

        self._duration_label = tk.Label(
            footer_row,
            text="Durée totale : 0:00",
            bg=theme.BG_DARK,
            fg=theme.TEXT_MUTED,
            font=theme.FONT_SMALL,
        )
        self._duration_label.pack(side="left")

        self._char_count_label = tk.Label(
            footer_row,
            text=f"0 / {MAX_CHARS} caractères",
            bg=theme.BG_DARK,
            fg=theme.TEXT_MUTED,
            font=theme.FONT_SMALL,
        )
        self._char_count_label.pack(side="right")

    # ------------------------------------------------------------------
    def _build_footer_actions(self) -> None:
        actions = tk.Frame(self, bg=theme.BG_DARK)
        actions.place(relx=0.5, rely=0.85, anchor="center")

        self._generate_btn = ttk.Button(
            actions,
            text="Générer le modèle de vibration →",
            style="Accent.TButton",
            command=self._on_generate,
        )
        self._generate_btn.grid(row=0, column=0, padx=(0, 12))

        self._pause_btn = ttk.Button(
            actions,
            text="Pause",
            style="Secondary.TButton",
            command=self._on_pause_toggle,
            state="disabled",
        )
        self._pause_btn.grid(row=0, column=1)

        self._progress_label = tk.Label(
            self,
            text="",
            bg=theme.BG_DARK,
            fg=theme.TEXT_SECONDARY,
            font=theme.FONT_SMALL,
        )
        self._progress_label.place(relx=0.5, rely=0.93, anchor="center")

    # ------------------------------------------------------------------
    # Saisie de texte
    # ------------------------------------------------------------------
    def _on_text_modified(self, event=None) -> None:
        # Le flag <<Modified>> de tkinter.Text doit être réinitialisé
        # manuellement, sinon l'événement ne se redéclenche plus.
        self._text_widget.edit_modified(False)
        content = self._text_widget.get("1.0", "end-1c")
        count = len(content)
        if count > MAX_CHARS:
            # Tronque au-delà de la limite plutôt que de bloquer la saisie.
            self._text_widget.delete(f"1.0+{MAX_CHARS}c", "end")
            count = MAX_CHARS
        self._char_count_label.config(text=f"{count} / {MAX_CHARS} caractères")

        if not self._playing:
            self._update_duration_preview(content)

    def _update_duration_preview(self, content: str) -> None:
        """Recalcule et affiche la durée totale de la séquence saisie,
        tant qu'aucune lecture n'est en cours (pendant la lecture, ce
        label devient un compte à rebours géré par _tick_countdown)."""
        try:
            commands = parse_sequence(content)
        except ValueError:
            commands = []

        if not commands:
            self._duration_label.config(text="Durée totale : 0:00")
            return

        if any(c.duration <= 0 for c in commands):
            # Une durée de 0 = boucle indéfinie côté toy : pas de total fini.
            self._duration_label.config(text="Durée totale : indéterminée (boucle infinie)")
            return

        total = sum(c.duration for c in commands)
        self._duration_label.config(text=f"Durée totale : {_format_mmss(total)}")

    def get_text(self) -> str:
        return self._text_widget.get("1.0", "end-1c")

    # ------------------------------------------------------------------
    # Génération / exécution de la séquence
    # ------------------------------------------------------------------
    def _on_generate(self) -> None:
        if self._playing:
            return

        content = self.get_text().strip()
        if not content:
            self._flash_progress("Écris ou colle d'abord une séquence [Y;D;[A;B]].", theme.WARNING)
            return

        try:
            commands = parse_sequence(content)
        except ValueError as exc:
            self._flash_progress(f"Séquence invalide : {exc}", theme.DANGER)
            return

        if not commands:
            self._flash_progress(
                "Aucune commande valide trouvée. Format attendu : [Y;D;[A;B]] "
                "(ex: [3;2;[10;15]]).",
                theme.WARNING,
            )
            return

        if not self.controller.state.connected:
            # Pas de toy connecté : on redirige vers la page de connexion
            # plutôt que d'échouer silencieusement.
            self.controller.show_page("connection")
            return

        self._start_playback(commands)

    def _start_playback(self, commands: list[VibrationCommand]) -> None:
        client = self.controller.state.client
        self._stop_event = threading.Event()
        self._pause_event = threading.Event()
        self._playing = True
        self._generate_btn.config(state="disabled", text="Lecture en cours…")
        self._pause_btn.config(state="normal", text="Pause")
        total = len(commands)
        self._set_progress(f"Commande 1/{total}…", theme.SUCCESS)

        # Démarre le compte à rebours si la durée totale est connue
        # (pas de commande à durée indéfinie).
        if any(c.duration <= 0 for c in commands):
            self._remaining_seconds = 0
            self._duration_label.config(text="Durée totale : indéterminée (boucle infinie)")
        else:
            self._remaining_seconds = float(sum(c.duration for c in commands))
            self._duration_label.config(text=f"Temps restant : {_format_mmss(self._remaining_seconds)}")
            self.after(_COUNTDOWN_TICK_MS, self._tick_countdown)

        def on_command_start(index: int, total_: int, command: VibrationCommand) -> None:
            self.after(0, lambda: self._set_progress(
                f"Commande {index + 1}/{total_} — {command}", theme.SUCCESS
            ))

        def worker() -> None:
            try:
                play_sequence(
                    client,
                    commands,
                    stop_event=self._stop_event,
                    pause_event=self._pause_event,
                    on_command_start=on_command_start,
                )
                interrupted = self._stop_event.is_set()
            except Exception as exc:
                self.after(0, lambda: self._on_playback_error(exc))
                return
            self.after(0, lambda: self._on_playback_finished(total, interrupted))

        threading.Thread(target=worker, daemon=True).start()

    def _tick_countdown(self) -> None:
        if not self._playing:
            return  # la lecture est terminée : on arrête de rafraîchir
        if self._pause_event is not None and self._pause_event.is_set():
            # En pause : le décompte reste figé, mais on continue de
            # vérifier périodiquement pour reprendre dès que possible.
            self.after(_COUNTDOWN_TICK_MS, self._tick_countdown)
            return
        self._remaining_seconds = max(0.0, self._remaining_seconds - _COUNTDOWN_TICK_MS / 1000)
        self._duration_label.config(text=f"Temps restant : {_format_mmss(self._remaining_seconds)}")
        if self._remaining_seconds > 0:
            self.after(_COUNTDOWN_TICK_MS, self._tick_countdown)

    def _on_pause_toggle(self) -> None:
        if not self._playing or self._pause_event is None:
            return
        if self._pause_event.is_set():
            # Actuellement en pause -> on reprend.
            self._pause_event.clear()
            self._pause_btn.config(text="Pause")
            self._set_progress("Reprise…", theme.SUCCESS)
        else:
            # Actuellement en lecture -> on met en pause (coupe le toy).
            self._pause_event.set()
            self._pause_btn.config(text="Reprendre")
            self._set_progress("En pause.", theme.WARNING)

    def _on_back(self) -> None:
        # Si une séquence est en cours de lecture, on l'arrête proprement
        # avant de quitter la page (sinon le thread continuerait à
        # piloter le toy en arrière-plan).
        if self._playing and self._stop_event is not None:
            self._stop_event.set()
            if self._pause_event is not None:
                self._pause_event.clear()  # ne pas rester bloqué en pause
        self.controller.show_page("home")

    def _on_playback_finished(self, total: int, interrupted: bool) -> None:
        self._playing = False
        self._stop_event = None
        self._pause_event = None
        self._generate_btn.config(state="normal", text="Générer le modèle de vibration →")
        self._pause_btn.config(state="disabled", text="Pause")
        if interrupted:
            self._set_progress("Séquence arrêtée.", theme.WARNING)
        else:
            self._set_progress(f"Terminé ✓ — {total} commande(s) jouée(s).", theme.SUCCESS)
        self._update_duration_preview(self.get_text())

    def _on_playback_error(self, exc: Exception) -> None:
        self._playing = False
        self._stop_event = None
        self._pause_event = None
        self._generate_btn.config(state="normal", text="Générer le modèle de vibration →")
        self._pause_btn.config(state="disabled", text="Pause")
        self._set_progress(f"Erreur pendant la lecture : {exc}", theme.DANGER)
        self._update_duration_preview(self.get_text())

    def _set_progress(self, text: str, color: str) -> None:
        self._progress_label.config(text=text, fg=color)

    # ------------------------------------------------------------------
    def _flash_progress(self, message: str, color: str) -> None:
        self._set_progress(message, color)
        self.after(4000, lambda: self._set_progress("", theme.TEXT_SECONDARY))

    def _flash_connection_label(self, message: str) -> None:
        default_text = self._connection_status_text()
        self._connection_label.config(text=message, fg=theme.TEXT_PRIMARY)
        self.after(3000, lambda: self._connection_label.config(
            text=default_text, fg=theme.TEXT_SECONDARY
        ))

    def _connection_status_text(self) -> str:
        state = self.controller.state
        if state.connected:
            return f"{state.primary_toy_name() or 'Edge 2'} connecté"
        return "Toy non connecté"

    # Appelé automatiquement par AppWindow.show_page()
    def on_show(self) -> None:
        self._connection_label.config(text=self._connection_status_text(), fg=theme.TEXT_SECONDARY)
        if not self._playing:
            self._update_duration_preview(self.get_text())
        if not self.controller.state.connected:
            # La connexion a pu être perdue entre-temps : on ne bloque pas
            # la page, mais on prévient clairement.
            self._flash_connection_label(
                "Toy non connecté — clique sur Générer te redirigera vers la connexion."
            )
